import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function AnalyticsPage() {
  const metrics = [
    { title: "Daily Revenue", value: "$2,847", change: "+12.5%", trend: "up" },
    { title: "Orders Today", value: "127", change: "+8.2%", trend: "up" },
    { title: "Avg Order Value", value: "$22.41", change: "-2.1%", trend: "down" },
    { title: "Customer Satisfaction", value: "4.8/5", change: "+0.2", trend: "up" },
  ]

  const topDishes = [
    { name: "Quantum Burger", orders: 45, revenue: "$675" },
    { name: "Nebula Pasta", orders: 38, revenue: "$532" },
    { name: "Cosmic Pizza", orders: 32, revenue: "$448" },
    { name: "Stellar Salad", orders: 28, revenue: "$336" },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white">Analytics Dashboard</h1>
        <p className="text-slate-400 mt-2">Track performance and insights</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {metrics.map((metric) => (
          <Card key={metric.title} className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-slate-300 text-sm font-medium">{metric.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{metric.value}</div>
              <Badge
                variant="outline"
                className={`mt-2 ${
                  metric.trend === "up" ? "text-green-400 border-green-400" : "text-red-400 border-red-400"
                }`}
              >
                {metric.change}
              </Badge>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Top Performing Dishes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {topDishes.map((dish, index) => (
              <div key={dish.name} className="flex items-center justify-between p-3 rounded-lg bg-slate-700/30">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center text-white font-bold">
                    {index + 1}
                  </div>
                  <div>
                    <p className="text-white font-medium">{dish.name}</p>
                    <p className="text-slate-400 text-sm">{dish.orders} orders</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-white font-bold">{dish.revenue}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
